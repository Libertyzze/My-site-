const nav = document.getElementById('nav');

function openNav() {
  if (nav.style.display == 'none') {
    nav.style.display = 'block';
  } else {
    nav.style.display = 'none'
  }
}